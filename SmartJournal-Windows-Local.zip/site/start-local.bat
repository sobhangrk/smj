@echo off
setlocal
chcp 65001 >nul 2>nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install the LTS version from https://nodejs.org
  pause
  exit /b 1
)
if "%LOCAL_PORT%"=="" set "LOCAL_PORT=3030"
echo Starting SmartJournal in LOCAL-ONLY mode (no phone, no cloud sync).
start "SmartJournal local journal - close to stop" /D "%~dp0" cmd /k "set LOCAL_PORT=%LOCAL_PORT%&& node local-server.js"
node -e "var n=0;function p(){require('http').get({host:'127.0.0.1',port:%LOCAL_PORT%,path:'/journal'},function(r){process.exit(r.statusCode===200?0:1)}).on('error',function(){if(++n>80)process.exit(1);setTimeout(p,250)})}p()"
if errorlevel 1 (
  echo Local server did not start. Check the other command window.
  pause
  exit /b 1
)
start "" "http://127.0.0.1:%LOCAL_PORT%/journal"
echo Journal opened. Leave the server window open while using it.
