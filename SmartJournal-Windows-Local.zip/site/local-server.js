'use strict';
// Local-only static host for the personal, no-phone Windows launcher.
// Deliberately binds to loopback and never starts the cloud/API server.
const http = require('http');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, 'public');
const host = '127.0.0.1';
const port = Number(process.env.LOCAL_PORT || 3030);
const types = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.json':'application/json; charset=utf-8', '.svg':'image/svg+xml', '.png':'image/png', '.jpg':'image/jpeg', '.jpeg':'image/jpeg', '.webp':'image/webp', '.woff':'font/woff', '.woff2':'font/woff2', '.ico':'image/x-icon', '.mp4':'video/mp4', '.webm':'video/webm' };
function send(res, status, text) { res.writeHead(status, {'content-type':'text/plain; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}); res.end(text); }
const server = http.createServer((req, res) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, `http://${host}:${port}`).pathname); }
  catch { return send(res, 400, 'Bad request'); }
  if (pathname === '/' || pathname === '/journal' || pathname === '/journal/') pathname = '/index.html';
  if (pathname.startsWith('/journal/')) pathname = pathname.slice('/journal'.length) || '/index.html';
  let file = path.resolve(root, '.' + pathname);
  if (!file.startsWith(root + path.sep) && file !== path.join(root, 'index.html')) return send(res, 403, 'Forbidden');
  fs.stat(file, (err, stat) => {
    if (err || !stat.isFile()) {
      // App navigation uses history routes; serve the same local shell for them.
      file = path.join(root, 'index.html');
    }
    fs.readFile(file, (readErr, data) => {
      if (readErr) return send(res, 404, 'Not found');
      if (path.basename(file) === 'index.html') {
        // Disable all cloud account/session code in this explicitly local mode.
        data = Buffer.from(data.toString('utf8').replace(/\s*<script src="\/journal-cloud\.js"><\/script>/, ''));
      }
      res.writeHead(200, {'content-type':types[path.extname(file).toLowerCase()] || 'application/octet-stream','cache-control':'no-store','x-content-type-options':'nosniff','content-length':data.length});
      res.end(req.method === 'HEAD' ? undefined : data);
    });
  });
});
server.on('error', err => { console.error(`SmartJournal local server: ${err.message}`); process.exitCode = 1; });
server.listen(port, host, () => console.log(`SmartJournal local-only journal: http://${host}:${port}/journal (loopback only)`));
